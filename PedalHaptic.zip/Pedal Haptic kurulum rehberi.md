# Pedal Haptic kurulum rehberi

ACC, LMU ve iRacing için SimHub gerektirmeyen pedal titreşim sistemi. Sürüm 1.

## Pakette neler var

|Dosya|Ne işe yarar|
|-|-|
|PedalHaptic.py|Bilgisayar uygulaması (arayüz, telemetri, efektler)|
|PedalHaptic.ino|Arduino'ya yüklenen kod|
|1\_kurulum.bat|Gerekli kütüphaneyi kurar (tek seferlik)|
|2\_baslat.bat|Uygulamayı açar|

## Gerekenler

* Arduino Uno ve L293D motor shield
* Fren motoru shield'de M1, gaz motoru M2 girişinde
* Veri aktarabilen USB kablo (sadece şarj kablosu çalışmaz)
* Windows bilgisayar, Python ve Arduino IDE (aşağıda kurulumu var)

## Kurulum, sırayla

### 1\. Dosyaları hazırla

PedalHaptic klasörünü masaüstüne koy. Arduino IDE kodu açarken PedalHaptic.ino'nun aynı adlı bir klasör içinde olmasını ister. Bu madde hazır sekildedir dosyayı direk zipten çıkarabilirsiniz.

### 2\. Python'u kur

* python.org/downloads adresinden indir.
* Kurulumun ilk ekranında **Add python.exe to PATH** kutusunu işaretle, sonra Install Now.

### 3\. Kütüphaneyi kur

1\_kurulum.bat dosyasına çift tıkla. "Successfully installed pyserial" yazarsa tamam. Bu adım bir kere yapılır.

### 4\. Arduino'ya kodu yükle

1. SimHub'ı tamamen kapat, sağ alttaki simgeden de çık.
2. Arduino IDE'yi aç (yoksa arduino.cc'den ücretsiz indir). Arduino USB'ye takılı olsun.
3. PedalHaptic.ino dosyasını aç.
4. Sketch > Include Library > Manage Libraries: "Adafruit Motor Shield library" ara ve **V1** olanı kur (adında V2 yazan değil).
5. Tools > Board > Arduino AVR Boards > **Arduino Uno**.
6. Tools > Port: Arduino'nun portunu seç (örneğin COM3).
7. Upload (ok) tuşuna bas. "Done uploading" yazınca IDE'yi kapat, yoksa portu tutar.

### 5\. Uygulamayı başlat

1. 2\_baslat.bat dosyasına çift tıkla.
2. Arduino portunu seç ve **Baglan**'a bas. İki saniye sonra "Bagli" yazar, sağda gecikme görünür.
3. Sağ üstten oyunu seç: **ACC**, **LMU** veya **iRacing**.

## Motor testi (oyun açmadan)

Her efektin yanındaki **Test (1 sn)** düğmesini dene:

* ABS ve Kilitlenme efektleri **fren** motorunu çalıştırmalı.
* TC ve Kayma efektleri **gaz** motorunu çalıştırmalı.
* Ters çalışıyorsa motor kablolarını shield'de M1 ve M2 arasında değiştir.

## Başlangıç ayarları

|Efekt|Şiddet|Frekans|Tutma|His|
|-|-|-|-|-|
|ABS|80-100|12-15 Hz|60 ms|Gerçek ABS gibi darbeli pedal|
|Kilitlenme|90-100|0 (sürekli)|50 ms|Sert ve kesintisiz uyarı|
|TC|60-70|8-10 Hz|60 ms|Yavaş darbeli, ABS'den ayırt edilebilir|
|Kayma|40-60|0 (sürekli)|50 ms|Hafif, sürekli vızıltı|

* Şiddet yaklaşık %30-40 altında motor hiç dönmeyebilir.
* 20-25 Hz üstündeki darbeler birbirine karışır. Net darbe için 5-20 Hz kullan.
* Darbe hissetmiyorsan frekansı düşür, tutma süresini 80-100 ms yap.
* Kilitlenme ve kayma için **Esik** kaydırıcısı hassasiyeti belirler. Çok erken titriyorsa yükselt, hiç titremiyorsa düşür. Canlı değerler arayüzde görünür.
* Ayarları her oyun için ayrı profil olarak kaydet (ACC, LMU, iRacing).

## Oyunlara göre durum

|Oyun|ABS|TC|Not|
|-|-|-|-|
|ACC|Oyundan doğrudan|Oyundan doğrudan|En güvenilir seçenek, önce bununla test et|
|iRacing|Oyundan doğrudan|Kayma verisinden türetilir|Ek eklenti gerekmez, telemetri saniyede 60 güncelleme|
|LMU|Kayma verisinden türetilir|Kayma verisinden türetilir|Deneysel, aşağıya bak|

### LMU için ek adım

LMU'yu rFactor 2 paylaşımlı bellek yöntemiyle okuyorum. Bunun için rF2SharedMemoryMapPlugin64.dll dosyasını LMU klasöründeki Plugins içine koyup oyunda eklentileri açman gerekir. LMU'nun yeni bir kendi sistemi de var, güncel sürüm eski yolu kabul etmeyebilir. "veri kaynağı bulunamadı" yazarsa bunu not et, yeni yönteme geçilir.

## Sorun giderme

|Sorun|Ne yapmalı|
|-|-|
|1\_kurulum.bat "py bulunamadı" diyor|Python'u PATH kutusu işaretli şekilde yeniden kur|
|Port listesi boş|USB'yi çıkarıp tak, başka USB portu dene, veri kablosu kullan|
|"Baglanilamadi" hatası|SimHub'ı ve Arduino IDE Serial Monitor'ü kapat|
|Motor hiç dönmüyor|Şiddeti yükselt, motorun harici 12V besleme bağlantısını kontrol et|
|Hep aynı pedal titriyor|M1 ve M2 kablolarını değiştir|
|"veri kaynağı bulunamadı"|Oyun açık mı, pistte misin, doğru oyunu seçtin mi|
|"veri yapisi uyusmuyor"|Ekranı not et, düzeltme gerekir|
|Düz yolda kayma değeri sürekli yüksek|iRacing veya LMU birimi uyuşmuyor olabilir, bildir|
|SimHub'a geri dönmek|SimHub'dan Arduino kodunu yeniden yükle|

## Bilinen sınırlar

* Bu sürüm gerçek oyunlarla denenmeden yazıldı. İlk testte eşiklerin ve değerlerin ayarlanması gerekebilir.
* Titreşim motorları dönmeye başlarken 30-80 ms gecikir. Yazılım gecikmesi buna eklenmez ama bu fiziksel gecikme sıfırlanamaz.
* Seri gecikme sağ üstte canlı görünür. Motorun kendi gecikmesini içermez.
* Bilgisayar bağlantıyı keserse motorlar 150 ms içinde kendiliğinden durur.
* Ve Uygulama içinde Arduino ve port seçme kısmında otomatik seçecektir ama seçmezse veya yanlış portu seçmesi durumunda buradan kendi cihazınız hangi porttayse seçebilirsiniz
* Bağlı portu öğrenmek için aygıt yöneticisinden bağlantı noktalarına bakabilirsiniz

